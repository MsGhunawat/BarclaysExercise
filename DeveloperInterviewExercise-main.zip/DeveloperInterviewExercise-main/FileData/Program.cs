﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            GetFileDetail(args);
        }

        private static void GetFileDetail(string[] args)
        {
            try
            {
                var FileDetails = new FileDetails();
                if (new string[] { "-v", "--v", @"/ v", "--version" }.Contains(args[0]))
                    Console.WriteLine(FileDetails.Version(args[1]));
                else if (new string[] { "-s", "--s", @"/ s", "--size" }.Contains(args[0]))
                    Console.WriteLine(FileDetails.Size(args[1]));
                else
                    Console.WriteLine("Invalid argument, Kindly provide valid argument(s)");
            }
            catch(Exception ex)
            {
                Console.WriteLine("Unhandled exception occured : -" + ex.Message);
            }
            
        }
    }
}
