﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FileData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileData;
using ThirdPartyTools;

namespace FileData.Tests
{
    [TestClass()]
    public class Program
    {
        [TestMethod()]
        public void GetVersion()
        {
            // Arrange
            FileDetails objFileDetails = new FileDetails();

            // Act
            var version = objFileDetails.Version("c:/temp/text.txt");

            // Assert
            Assert.IsNotNull(version, "File version fetched");

        }

        [TestMethod()]
        public void GetSize()
        {
            // Arrange
            FileDetails objFileDetails = new FileDetails();

            // Act
            var size = objFileDetails.Size("c:/temp/text.txt");


            // Assert
            Assert.IsTrue(size > 0, "File is not empty");

        }
    }
}